<?php echo "PHP работает!";
